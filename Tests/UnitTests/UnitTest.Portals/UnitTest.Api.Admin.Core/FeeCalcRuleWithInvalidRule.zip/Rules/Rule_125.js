if (Is_Residential && Is_NewDwellings && !isNaN(Num_NewDwellings) && Num_NewDwellings > 50) 
{
    Fee = Math.min(parseFloat(NewDwellingFlatCharge) + ((parseInt(Num_NewDwellings) - 50) * parseFloat(AdditionalNewDwellingCharge)), parseFloat(MaxNewDwellingCharge));
	if (Language == "cy_wa") 
		desc = NewDwellingFlatCharge + " + " + ((Num_NewDwellings – 50) * NewDwellingFlatCharge).toString() + " for the additional " + (Num_NewDwellings – 50) + " houses";
	else 
		desc = NewDwellingFlatCharge + " + " + ((Num_NewDwellings – 50) * NewDwellingFlatCharge).toString() + " ar gyfer y " + (Num_NewDwellings – 50) + " tŷ ychwanegol";
	
	output = {
        "description": desc,
        "outputparametervalue": Fee
    };
	return JSON.stringify(output)
}
